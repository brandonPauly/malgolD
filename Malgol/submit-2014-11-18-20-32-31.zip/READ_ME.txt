Group:
Brandon Pauly
Jesus Zapata
Jacob Powell

So far tests 1-11 work, and A-H already work.  If you are reading this, I suppose it means we haven't figured out the 
arrays part yet.  We are going to continue to work, but time permitting, may not get the last part done.